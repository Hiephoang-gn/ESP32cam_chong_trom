from flask import Flask, request, Response, render_template_string
from flask_mail import Mail, Message
import requests
import os
from datetime import datetime
import time
from requests.exceptions import ReadTimeout, ConnectionError

app = Flask(__name__)

# ========== Cấu hình Gmail ==========
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'hoanghiephoaan@gmail.com'  # Gmail gửi
app.config['MAIL_PASSWORD'] = 'ornk sdmi abxg eccu'        # Mật khẩu ứng dụng
app.config['MAIL_DEFAULT_SENDER'] = 'hoanghiephoaan@gmail.com'

mail = Mail(app)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 🔧 IP và port ESP32-CAM 
ESP32_CAM_STREAM_URL = "http://172.20.10.2/stream"

# ========== Giao diện chính ==========
@app.route('/')
def index():
    return render_template_string("""
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <title>📷 Hệ Thống Giám Sát ESP32-CAM</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
        <style>
            body {
                background: linear-gradient(to right, #f8f9fa, #e9ecef);
                font-family: 'Segoe UI', sans-serif;
            }
            .container {
                max-width: 950px;
                margin-top: 50px;
            }
            .card {
                border-radius: 20px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            }
            .header-text {
                font-weight: 600;
                font-size: 1.8rem;
                color: #0d6efd;
            }
            .footer {
                margin-top: 50px;
                font-size: 0.9rem;
                color: #6c757d;
                text-align: center;
            }
            .stream-box img {
                border: 4px solid #dee2e6;
                border-radius: 10px;
                max-height: 480px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="card p-4">
                <div class="text-center">
                    <div class="header-text mb-3"><i class="fas fa-video"></i> ESP32-CAM Giám Sát Trực Tuyến</div>
                    <div class="stream-box mb-3">
                        <img src="{{ url_for('video_feed') }}" class="img-fluid" alt="ESP32-CAM Stream">
                    </div>
                    <div class="alert alert-danger" role="alert">
                        <i class="fas fa-exclamation-triangle"></i> Hệ thống sẽ <strong>tự động gửi email</strong> nếu phát hiện có người đột nhập!
                    </div>
                </div>
                <div class="text-center mt-4">
                    <button class="btn btn-outline-primary btn-lg" onclick="location.reload()">
                        <i class="fas fa-sync-alt"></i> Làm mới luồng
                    </button>
                </div>
            </div>
            <div class="footer mt-4">
                © 2025 - Giám sát thông minh bằng ESP32-CAM | Thiết kế bởi <strong>HIEPHOANG</strong>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    """)

# ========== Xử lý MJPEG từ ESP32-CAM ==========
@app.route('/video_feed')
def video_feed():
    def stream():
        max_retries = 3
        for attempt in range(max_retries):
            try:
                print(f"[🔍] Đang kết nối tới ESP32-CAM tại: {ESP32_CAM_STREAM_URL} (lần thử {attempt+1}/{max_retries})")
                r = requests.get(ESP32_CAM_STREAM_URL, stream=True, timeout=10)
                for chunk in r.iter_content(chunk_size=512):  # chunk nhỏ hơn tránh timeout
                    if chunk:
                        yield chunk
                break
            except ReadTimeout:
                print("[❌] Lỗi timeout khi kết nối ESP32-CAM, thử lại...")
            except ConnectionError as ce:
                print(f"[❌] Lỗi kết nối (ConnectionError): {ce}, thử lại...")
            except ConnectionResetError as cre:
                print(f"[❌] Kết nối bị reset bởi ESP32-CAM (ConnectionResetError): {cre}, thử lại...")
            except Exception as e:
                print(f"[❌] Lỗi khác khi kết nối ESP32-CAM: {e}")
                break
            time.sleep(1)
        else:
            print("[❌] Không thể kết nối tới ESP32-CAM sau nhiều lần thử.")
            yield b''

    return Response(stream(), mimetype='multipart/x-mixed-replace; boundary=frame')

# ========== Nhận ảnh từ ESP32-CAM gửi về ==========
@app.route('/upload', methods=['POST'])
def upload():
    if request.headers.get('Content-Type') != 'image/jpeg':
        return "Yêu cầu định dạng image/jpeg", 400

    img_data = request.data
    if not img_data:
        return "Không có ảnh", 400

    filename = datetime.now().strftime("%Y%m%d_%H%M%S.jpg")
    filepath = os.path.join(UPLOAD_FOLDER, filename)

    with open(filepath, 'wb') as f:
        f.write(img_data)

    try:
        msg = Message(subject="🚨 Cảnh báo đột nhập từ ESP32-CAM",
                      recipients=["receiver_email@gmail.com"])  # Thay bằng email người nhận
        msg.body = "⚠️ Hệ thống phát hiện có người đột nhập. Xem ảnh đính kèm."
        with app.open_resource(filepath) as fp:
            msg.attach(filename, "image/jpeg", fp.read())
        mail.send(msg)
        print(f"[✅] Đã gửi email với ảnh: {filename}")
    except Exception as e:
        print(f"[❌] Lỗi gửi email: {e}")
        return "Lỗi gửi email", 500

    return "Đã nhận và gửi email!", 200

# ========== Chạy Flask ==========
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
